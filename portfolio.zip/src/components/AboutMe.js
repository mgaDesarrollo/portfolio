import React from 'react'



const AboutMe = () => {
    return (
        <div className="about-me" >
            <a name='aboutMe'></a>
            <div className="about-photo">

            </div>
            <div className="about-text">

            <section>
            <h3 className="about-title">About Me</h3>
            <br/>
            <br/>

            <p>Hello, my name is Gabriel Avendaño, I am passionate about programming and technology, I am studying the last semester of programming technique in utn-frc, I am looking for my first job as a programmer, I have a repository with my projects done in different programming languages like java, c #, javaScript, python, react, nodeJs, html, css and bootstrap. </p>
            </section>
            </div>
        </div>
    )
}

export default AboutMe
